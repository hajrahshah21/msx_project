from django.apps import AppConfig


class MsxConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'msx'
