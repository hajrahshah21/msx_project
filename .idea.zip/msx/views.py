from django.shortcuts import render
from.models import Request
requests = [
    {
        'author': 'Steve.Ch',
        'title': 'msx request 1',
        'content': 'First msx request!',
        'date_posted': 'February 21st, 2023'
    },
    {
        'author': 'Laura.S',
        'title': 'msx request 2',
        'content': 'Second msx request!',
        'date_posted': 'February 25th, 2023'
    }
]

def home(request):
    context = {
        'requests': Request.objects.all()
    }
    return render(request, 'msx/home.html', context)


def about(request):
    return render(request, 'msx/about.html', {'title': 'About'})


